#ifndef CONFIG_H
#define CONFIG_H

//#define WIFI_SSID "POCO X6 Pro 5G"
//#define WIFI_PASSWORD "gooddays"
//^^ elena

//#define WIFI_SSID "Fernando1"
//#define WIFI_PASSWORD "gEMTy4567"
//#define MQTT_IP "172.20.10.8"
//^^ fernando

#define WIFI_SSID "Totalplay-04AF"
#define WIFI_PASSWORD "04AF0B8FunPvY5hY"
#define MQTT_IP "192.168.100.72"
//^^ sofia casa 192.168.100.72

//#define WIFI_SSID "INFINITUM2EA3"
//#define WIFI_PASSWORD "HXwCtxY5Lz"
//#define MQTT_IP "192.168.1.77" 
//^^ mi casa

//#define MQTT_IP "172.20.10.8"
//#define MQTT_IP "10.183.121.46"
//#define MQTT_IP "10.13.214.46"
#endif