struct pms5003data {
  uint16_t framelen;
  uint16_t pm10_standard, pm25_standard, pm100_standard;
  uint16_t pm10_env, pm25_env, pm100_env;
  uint16_t particles_03um, particles_05um, particles_10um, particles_25um, particles_50um, particles_100um;
  uint16_t unused;
  uint16_t checksum;
};
 
struct pms5003data data;
int eventCount = 0; //counts the loop, which iterates every second
int ppm25 = 0;
int avgPpm25 = 0;
//600 seconds = 10mins - I want to calc an average every 10 mins
int secsToPost = 600; //number of seconds to wait - also the divisor for avg
String urlVars; //will hold the GET values sent to my website
bool debugPrints = false;

void urlvars(){

      if (eventCount == secsToPost) {
      avgPpm25 = ppm25 / secsToPost;
      urlVars = String(avgPpm25) + "|" + String(data.pm10_standard) + "|" + String(data.pm25_standard) + "|" + String(data.pm100_standard);
      urlVars += "|" + String(data.pm10_env) + "|" + String(data.pm25_env) + "|" + String(data.pm100_env);
      Serial.println("Average: " + String(avgPpm25) + "|" + eventCount); 
      avgPpm25 = 0;
      ppm25 = 0;
      eventCount = 0;
      Serial.println("---------------+++++-------------------");
    }
}


boolean readPMSdata(Stream *s) {
  if (! s->available()) {
    if (debugPrints) { 
    Serial.println("no s available failure");
    }
    return false;
  }
  
  // Read a byte at a time until we get to the special '0x42' start-byte
  if (s->peek() != 0x42) {
    if (debugPrints) {
    Serial.print("peak 0x42 failure -> ");
    Serial.println(s->peek());
    }
    
    s->read();
    return false;
  }
  
  if (debugPrints) {
  Serial.print("peak 0x42 success -> ");
  Serial.println(s->peek());
  }
 
  // Now read all 32 bytes
  if (s->available() < 32) {
    if (debugPrints) {
    Serial.println("32 bit failure");
    }
    return false;
  }
    
  uint8_t buffer[32];    
  uint16_t sum = 0;
  s->readBytes(buffer, 32);
 
  // get checksum ready
  for (uint8_t i=0; i<30; i++) {
    sum += buffer[i];
  }
 
  /* debugging
  for (uint8_t i=2; i<32; i++) {
    Serial.print("0x"); Serial.print(buffer[i], HEX); Serial.print(", ");
  }
  Serial.println();
  */
  
  // The data comes in endian'd, this solves it so it works on all platforms
  uint16_t buffer_u16[15];
  for (uint8_t i=0; i<15; i++) {
    buffer_u16[i] = buffer[2 + i*2 + 1];
    buffer_u16[i] += (buffer[2 + i*2] << 8);
  }
 
  // put it into a nice struct :)
  memcpy((void *)&data, (void *)buffer_u16, 30);
 
  if (sum != data.checksum) {
    if (debugPrints) {
    Serial.println("Checksum failure");
    }
    return false;
  }
  // success!
  return true;
}
